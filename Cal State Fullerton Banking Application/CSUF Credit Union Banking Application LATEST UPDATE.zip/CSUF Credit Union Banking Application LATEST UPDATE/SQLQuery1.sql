﻿BEGIN TRANSACTION;

ALTER TABLE [dbo].[SavingsTbl]
ADD CONSTRAINT FK_SavingsTbl_AccountTbl
FOREIGN KEY (AccNum)
REFERENCES [dbo].[AccountTbl] (AccNum);


COMMIT TRANSACTION;