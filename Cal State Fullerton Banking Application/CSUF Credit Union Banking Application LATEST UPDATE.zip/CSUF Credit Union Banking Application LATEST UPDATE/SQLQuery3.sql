﻿DELETE FROM [dbo].[AccountTbl];
