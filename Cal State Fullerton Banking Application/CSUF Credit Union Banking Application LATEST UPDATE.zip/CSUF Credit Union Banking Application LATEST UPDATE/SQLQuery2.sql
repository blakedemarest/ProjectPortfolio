﻿ALTER TABLE [dbo].[AccountTbl]
DROP COLUMN Balance;
