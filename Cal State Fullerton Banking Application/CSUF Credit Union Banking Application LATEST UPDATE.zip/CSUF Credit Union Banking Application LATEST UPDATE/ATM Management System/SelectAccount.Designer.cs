﻿namespace ATM_Management_System
{
    partial class SelectAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label7 = new Label();
            label2 = new Label();
            label1 = new Label();
            label3 = new Label();
            CheckingBtn = new Button();
            SavingsBtn = new Button();
            label13 = new Label();
            pictureBox2 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateGray;
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 106);
            panel1.TabIndex = 6;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(761, 0);
            label7.Name = "label7";
            label7.Size = new Size(39, 40);
            label7.TabIndex = 4;
            label7.Text = "X";
            label7.Click += label7_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(1288, 0);
            label2.Name = "label2";
            label2.Size = new Size(39, 40);
            label2.TabIndex = 3;
            label2.Text = "X";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(108, 33);
            label1.Name = "label1";
            label1.Size = new Size(582, 40);
            label1.TabIndex = 2;
            label1.Text = "CSUF ATM MANAGEMENT SYSTEM";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Gadugi", 13.8F);
            label3.ForeColor = Color.DarkSlateGray;
            label3.Location = new Point(297, 141);
            label3.Name = "label3";
            label3.Size = new Size(194, 27);
            label3.TabIndex = 44;
            label3.Text = "Select an Account";
            // 
            // CheckingBtn
            // 
            CheckingBtn.BackColor = Color.DarkSlateGray;
            CheckingBtn.FlatStyle = FlatStyle.Popup;
            CheckingBtn.Font = new Font("Gadugi", 9F, FontStyle.Bold);
            CheckingBtn.ForeColor = SystemColors.Control;
            CheckingBtn.Location = new Point(85, 229);
            CheckingBtn.Name = "CheckingBtn";
            CheckingBtn.Size = new Size(194, 27);
            CheckingBtn.TabIndex = 47;
            CheckingBtn.Text = "CHECKING";
            CheckingBtn.UseVisualStyleBackColor = false;
            CheckingBtn.Click += CheckingBtn_Click;
            // 
            // SavingsBtn
            // 
            SavingsBtn.BackColor = Color.DarkSlateGray;
            SavingsBtn.FlatStyle = FlatStyle.Popup;
            SavingsBtn.Font = new Font("Gadugi", 9F, FontStyle.Bold);
            SavingsBtn.ForeColor = SystemColors.Control;
            SavingsBtn.Location = new Point(507, 229);
            SavingsBtn.Name = "SavingsBtn";
            SavingsBtn.Size = new Size(194, 27);
            SavingsBtn.TabIndex = 48;
            SavingsBtn.Text = "SAVINGS";
            SavingsBtn.UseVisualStyleBackColor = false;
            SavingsBtn.Click += SavingsBtn_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = SystemColors.Control;
            label13.Font = new Font("Gadugi", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.DarkSlateGray;
            label13.Location = new Point(366, 413);
            label13.Name = "label13";
            label13.Size = new Size(65, 28);
            label13.TabIndex = 49;
            label13.Text = "Back";
            label13.Click += label13_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Untitled_design__13_;
            pictureBox2.Location = new Point(323, 257);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(152, 153);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 50;
            pictureBox2.TabStop = false;
            // 
            // SelectAccount
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox2);
            Controls.Add(label13);
            Controls.Add(SavingsBtn);
            Controls.Add(CheckingBtn);
            Controls.Add(label3);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "SelectAccount";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SelectAccount";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label7;
        private Label label2;
        private Label label1;
        private Label label3;
        private Button CheckingBtn;
        private Button SavingsBtn;
        private Label label13;
        private PictureBox pictureBox2;
    }
}