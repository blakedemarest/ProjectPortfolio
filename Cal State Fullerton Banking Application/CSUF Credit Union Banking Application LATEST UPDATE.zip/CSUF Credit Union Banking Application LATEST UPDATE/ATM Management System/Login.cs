﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Management_System
{
    public partial class Login : Form
    {
        // Static variable to hold the account number for the session
        public static string AccNumber;

        // Connection string to the SQL database
        private readonly SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=C:\USERS\EARTH\DOCUMENTS\ATMDB.MDF;Integrated Security=True");

        public Login()
        {
            InitializeComponent();
        }

        // Event handler for label4 click
        private void label4_Click(object sender, EventArgs e)
        {
            // This method is currently empty. Add any logic needed for label4 click here.
        }

        // Event handler for label5 click to navigate to the Account form
        private void label5_Click(object sender, EventArgs e)
        {
            Account account = new Account();
            account.Show();
            this.Hide();
        }

        // Event handler for label6 click to exit the application
        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Event handler for the Login button click
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string query = "SELECT COUNT(*) FROM AccountTbl WHERE Accnum = @AccNum AND PIN = @Pin";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    // Use parameterized query to prevent SQL injection
                    cmd.Parameters.AddWithValue("@AccNum", AccNumTb.Text);
                    cmd.Parameters.AddWithValue("@Pin", PinTb.Text);

                    int result = (int)cmd.ExecuteScalar();
                    if (result == 1)
                    {
                        AccNumber = AccNumTb.Text;
                        HOME home = new HOME();
                        home.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Incorrect credentials, please try again.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                // Ensure the connection is closed even if an exception occurs
                con.Close();
            }
        }

        // Event handler for the Account Number text box text change
        private void AccNumTb_TextChanged(object sender, EventArgs e)
        {
            // You can add validation or other logic here if needed
        }
    }
}
