﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ATM_Management_System
{
    public partial class Balance : Form
    {
        public Balance()
        {
            InitializeComponent();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            HOME home = new HOME();
            this.Hide();
            home.Show();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=C:\USERS\EARTH\DOCUMENTS\ATMDB.MDF;Integrated Security=True");
        private void getbalance()
        {
            try
            {
                con.Open();

                // Query for checking balance
                SqlCommand cmdChecking = new SqlCommand("SELECT Balance FROM CheckingTbl WHERE AccNum=@AccNum", con);
                cmdChecking.Parameters.AddWithValue("@AccNum", AccNumberlbl.Text);
                var checkingBalance = cmdChecking.ExecuteScalar();

                if (checkingBalance != null)
                {
                    checkingBalanceinDollars.Text = "$ " + checkingBalance.ToString();
                }
                else
                {
                    checkingBalanceinDollars.Text = "$ 0";
                }

                // Query for savings balance
                SqlCommand cmdSavings = new SqlCommand("SELECT Balance FROM SavingsTbl WHERE AccNum=@AccNum", con);
                cmdSavings.Parameters.AddWithValue("@AccNum", AccNumberlbl.Text);
                var savingsBalance = cmdSavings.ExecuteScalar();

                if (savingsBalance != null)
                {
                    savingsBalanceinDollars.Text = "$ " + savingsBalance.ToString();
                }
                else
                {
                    savingsBalanceinDollars.Text = "$ 0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving balances: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        private void Balance_Load(object sender, EventArgs e)
        {
            AccNumberlbl.Text = HOME.AccNumber;
            getbalance();
        }

        private void AccNumberlbl_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Balancelbl_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
