﻿namespace ATM_Management_System
{
    partial class Balance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label7 = new Label();
            label2 = new Label();
            label1 = new Label();
            label5 = new Label();
            label3 = new Label();
            AccNumberlbl = new Label();
            savingsBalanceinDollars = new Label();
            panel2 = new Panel();
            label13 = new Label();
            label4 = new Label();
            checkingBalanceinDollars = new Label();
            pictureBox2 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateGray;
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 106);
            panel1.TabIndex = 2;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(761, 0);
            label7.Name = "label7";
            label7.Size = new Size(39, 40);
            label7.TabIndex = 4;
            label7.Text = "X";
            label7.Click += label7_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(1288, 0);
            label2.Name = "label2";
            label2.Size = new Size(39, 40);
            label2.TabIndex = 3;
            label2.Text = "X";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(108, 33);
            label1.Name = "label1";
            label1.Size = new Size(582, 40);
            label1.TabIndex = 2;
            label1.Text = "CSUF ATM MANAGEMENT SYSTEM";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.Control;
            label5.Font = new Font("Gadugi", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.DarkSlateGray;
            label5.Location = new Point(194, 133);
            label5.Name = "label5";
            label5.Size = new Size(191, 27);
            label5.TabIndex = 11;
            label5.Text = "Account Number:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.Control;
            label3.Font = new Font("Gadugi", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.DarkSlateGray;
            label3.Location = new Point(194, 285);
            label3.Name = "label3";
            label3.Size = new Size(180, 27);
            label3.TabIndex = 12;
            label3.Text = "Savings Balance:";
            // 
            // AccNumberlbl
            // 
            AccNumberlbl.AutoSize = true;
            AccNumberlbl.BackColor = SystemColors.Control;
            AccNumberlbl.Font = new Font("Gadugi", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            AccNumberlbl.ForeColor = Color.DarkSlateGray;
            AccNumberlbl.Location = new Point(421, 133);
            AccNumberlbl.Name = "AccNumberlbl";
            AccNumberlbl.Size = new Size(99, 27);
            AccNumberlbl.TabIndex = 13;
            AccNumberlbl.Text = "AccNum";
            AccNumberlbl.Click += AccNumberlbl_Click;
            // 
            // savingsBalanceinDollars
            // 
            savingsBalanceinDollars.AutoSize = true;
            savingsBalanceinDollars.BackColor = SystemColors.Control;
            savingsBalanceinDollars.Font = new Font("Gadugi", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            savingsBalanceinDollars.ForeColor = Color.DarkSlateGray;
            savingsBalanceinDollars.Location = new Point(421, 285);
            savingsBalanceinDollars.Name = "savingsBalanceinDollars";
            savingsBalanceinDollars.Size = new Size(257, 27);
            savingsBalanceinDollars.TabIndex = 14;
            savingsBalanceinDollars.Text = "savingsBalanceinDollars";
            savingsBalanceinDollars.Click += Balancelbl_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkSlateGray;
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 434);
            panel2.Name = "panel2";
            panel2.Size = new Size(800, 16);
            panel2.TabIndex = 34;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = SystemColors.Control;
            label13.Font = new Font("Gadugi", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.DarkSlateGray;
            label13.Location = new Point(346, 403);
            label13.Name = "label13";
            label13.Size = new Size(65, 28);
            label13.TabIndex = 35;
            label13.Text = "Back";
            label13.Click += label13_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.Control;
            label4.Font = new Font("Gadugi", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.DarkSlateGray;
            label4.Location = new Point(194, 205);
            label4.Name = "label4";
            label4.Size = new Size(202, 27);
            label4.TabIndex = 36;
            label4.Text = "Checking Balance: ";
            // 
            // checkingBalanceinDollars
            // 
            checkingBalanceinDollars.AutoSize = true;
            checkingBalanceinDollars.BackColor = SystemColors.Control;
            checkingBalanceinDollars.Font = new Font("Gadugi", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkingBalanceinDollars.ForeColor = Color.DarkSlateGray;
            checkingBalanceinDollars.Location = new Point(421, 205);
            checkingBalanceinDollars.Name = "checkingBalanceinDollars";
            checkingBalanceinDollars.Size = new Size(272, 27);
            checkingBalanceinDollars.TabIndex = 37;
            checkingBalanceinDollars.Text = "checkingBalanceinDollars";
            checkingBalanceinDollars.Click += label6_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Untitled_design__13_;
            pictureBox2.Location = new Point(12, 148);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(155, 146);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 38;
            pictureBox2.TabStop = false;
            // 
            // Balance
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox2);
            Controls.Add(checkingBalanceinDollars);
            Controls.Add(label4);
            Controls.Add(label13);
            Controls.Add(panel2);
            Controls.Add(savingsBalanceinDollars);
            Controls.Add(AccNumberlbl);
            Controls.Add(label3);
            Controls.Add(label5);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Balance";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Balance";
            Load += Balance_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label2;
        private Label label1;
        private Label label5;
        private Label label3;
        private Label AccNumberlbl;
        private Label savingsBalanceinDollars;
        private Panel panel2;
        private Label label13;
        private Label label7;
        private Label label4;
        private Label checkingBalanceinDollars;
        private PictureBox pictureBox2;
    }
}