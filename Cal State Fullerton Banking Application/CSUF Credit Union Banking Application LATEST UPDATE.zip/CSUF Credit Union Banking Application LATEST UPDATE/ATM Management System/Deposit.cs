﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Management_System
{
    public partial class Deposit : Form
    {
        public string AccountType { get; set; } // Property to hold the selected account type
        private int currentBalance;
        public string Acc = Login.AccNumber;
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=C:\USERS\EARTH\DOCUMENTS\ATMDB.MDF;Integrated Security=True");
        private readonly string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=C:\USERS\EARTH\DOCUMENTS\ATMDB.MDF;Integrated Security=True";

        public Deposit()
        {
            InitializeComponent();
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (DepoAmtTb.Text == "" || !int.TryParse(DepoAmtTb.Text, out int depositAmount) || depositAmount <= 0)
            {
                MessageBox.Show("Please enter a valid amount to deposit.");
                return;
            }

            else
            {
                DepositAmount(depositAmount);
            }
        }

        public void DepositAmount(int amount)
        {
            try
            {
                con.Open();
                string query = "";

                if (AccountType == "Checking")
                {
                    query = "UPDATE CheckingTbl SET Balance = Balance + @Amount WHERE AccNum = @AccNum";
                }
                else if (AccountType == "Savings")
                {
                    query = "UPDATE SavingsTbl SET Balance = Balance + @Amount WHERE AccNum = @AccNum";
                }

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Amount", amount);
                cmd.Parameters.AddWithValue("@AccNum", Acc);
                cmd.ExecuteNonQuery();
                MessageBox.Show($"Successfully Deposited ${amount} into your {AccountType} account.");
                con.Close();
                addtransaction(amount); // Pass amount to log transaction
                HOME home = new HOME();
                home.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }


        private void addtransaction(int amount) // Add amount parameter
        {
            string TrType = "Deposit";
            try
            {
                con.Open();
                string query = "INSERT INTO TransactionTbl (AccNum, Type, AccountType, Amount, Tdate) VALUES (@AccNum, @Type, @AccountType, @Amount, @Tdate)";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@AccNum", Acc);
                cmd.Parameters.AddWithValue("@Type", TrType);
                cmd.Parameters.AddWithValue("@AccountType", AccountType);
                cmd.Parameters.AddWithValue("@Amount", amount);
                cmd.Parameters.AddWithValue("@Tdate", DateTime.Now);

                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void accNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            HOME home = new HOME();
            home.Show();
            this.Hide();
        }
        int oldbalance, newbalance;
        private void Deposit_Load(object sender, EventArgs e)
        {
            getbalance();
        }
        private void getbalance()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "";

                    if (AccountType == "Checking")
                    {
                        query = "SELECT Balance FROM CheckingTbl WHERE AccNum = @AccNum";
                    }
                    else if (AccountType == "Savings")
                    {
                        query = "SELECT Balance FROM SavingsTbl WHERE AccNum = @AccNum";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@AccNum", Login.AccNumber);
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            currentBalance = Convert.ToInt32(dt.Rows[0]["Balance"]);
                            Balancelbl.Text = "$ " + currentBalance.ToString();
                        }
                        else
                        {
                            MessageBox.Show("Account not found.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving balance: " + ex.Message);
                }
            }
        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }
    }
}
