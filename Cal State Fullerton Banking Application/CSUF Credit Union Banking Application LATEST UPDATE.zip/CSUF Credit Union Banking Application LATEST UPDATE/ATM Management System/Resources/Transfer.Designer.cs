﻿namespace ATM_Management_System.Resources
{
    partial class Transfer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label7 = new Label();
            label2 = new Label();
            label1 = new Label();
            label3 = new Label();
            comboBox1 = new ComboBox();
            label4 = new Label();
            comboBox2 = new ComboBox();
            label5 = new Label();
            panel2 = new Panel();
            label6 = new Label();
            textBoxAmount = new TextBox();
            buttonTransfer_Click = new Button();
            label8 = new Label();
            pictureBox2 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateGray;
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 106);
            panel1.TabIndex = 7;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(761, 0);
            label7.Name = "label7";
            label7.Size = new Size(39, 40);
            label7.TabIndex = 4;
            label7.Text = "X";
            label7.Click += label7_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(1288, 0);
            label2.Name = "label2";
            label2.Size = new Size(39, 40);
            label2.TabIndex = 3;
            label2.Text = "X";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(108, 33);
            label1.Name = "label1";
            label1.Size = new Size(582, 40);
            label1.TabIndex = 2;
            label1.Text = "CSUF ATM MANAGEMENT SYSTEM";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Gadugi", 13.8F);
            label3.ForeColor = Color.DarkSlateGray;
            label3.Location = new Point(80, 139);
            label3.Name = "label3";
            label3.Size = new Size(188, 27);
            label3.TabIndex = 45;
            label3.Text = "TRANSFER FROM";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(80, 190);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(215, 28);
            comboBox1.TabIndex = 46;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Gadugi", 13.8F);
            label4.ForeColor = Color.DarkSlateGray;
            label4.Location = new Point(167, 236);
            label4.Name = "label4";
            label4.Size = new Size(41, 27);
            label4.TabIndex = 47;
            label4.Text = "TO";
            // 
            // comboBox2
            // 
            comboBox2.ForeColor = SystemColors.WindowText;
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(80, 275);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(215, 28);
            comboBox2.TabIndex = 48;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.Control;
            label5.Font = new Font("Gadugi", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.DarkSlateGray;
            label5.Location = new Point(354, 409);
            label5.Name = "label5";
            label5.Size = new Size(62, 19);
            label5.TabIndex = 49;
            label5.Text = "Log Out";
            label5.Click += label5_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkSlateGray;
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 431);
            panel2.Name = "panel2";
            panel2.Size = new Size(800, 19);
            panel2.TabIndex = 50;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Gadugi", 13.8F);
            label6.ForeColor = Color.DarkSlateGray;
            label6.Location = new Point(372, 139);
            label6.Name = "label6";
            label6.Size = new Size(110, 27);
            label6.TabIndex = 51;
            label6.Text = "AMOUNT";
            // 
            // textBoxAmount
            // 
            textBoxAmount.Font = new Font("Gadugi", 10F);
            textBoxAmount.Location = new Point(372, 190);
            textBoxAmount.Name = "textBoxAmount";
            textBoxAmount.Size = new Size(194, 30);
            textBoxAmount.TabIndex = 53;
            textBoxAmount.TextChanged += wdamtTb_TextChanged;
            // 
            // buttonTransfer_Click
            // 
            buttonTransfer_Click.BackColor = Color.DarkSlateGray;
            buttonTransfer_Click.FlatStyle = FlatStyle.Popup;
            buttonTransfer_Click.Font = new Font("Gadugi", 9F, FontStyle.Bold);
            buttonTransfer_Click.ForeColor = SystemColors.Control;
            buttonTransfer_Click.Location = new Point(372, 275);
            buttonTransfer_Click.Name = "buttonTransfer_Click";
            buttonTransfer_Click.Size = new Size(194, 27);
            buttonTransfer_Click.TabIndex = 54;
            buttonTransfer_Click.Text = "TRANSFER";
            buttonTransfer_Click.UseVisualStyleBackColor = false;
            buttonTransfer_Click.Click += button1_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = SystemColors.Control;
            label8.Font = new Font("Gadugi", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.DarkSlateGray;
            label8.Location = new Point(424, 317);
            label8.Name = "label8";
            label8.Size = new Size(75, 19);
            label8.TabIndex = 55;
            label8.Text = "GO BACK";
            label8.Click += label8_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Untitled_design__13_;
            pictureBox2.Location = new Point(591, 166);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(197, 170);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 56;
            pictureBox2.TabStop = false;
            // 
            // Transfer
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox2);
            Controls.Add(label8);
            Controls.Add(buttonTransfer_Click);
            Controls.Add(textBoxAmount);
            Controls.Add(label6);
            Controls.Add(panel2);
            Controls.Add(label5);
            Controls.Add(comboBox2);
            Controls.Add(label4);
            Controls.Add(comboBox1);
            Controls.Add(label3);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Transfer";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Transfer";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label7;
        private Label label2;
        private Label label1;
        private Label label3;
        private ComboBox comboBox1;
        private Label label4;
        private ComboBox comboBox2;
        private Label label5;
        private Panel panel2;
        private Label label6;
        private TextBox textBoxAmount;
        private Button buttonTransfer_Click;
        private Label label8;
        private PictureBox pictureBox2;
    }
}