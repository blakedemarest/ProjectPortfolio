﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Management_System.Resources
{
    public partial class Transfer : Form
    {
        public Transfer()
        {
            InitializeComponent();
            InitializeComboBoxes();
        }

        private readonly string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=C:\USERS\EARTH\DOCUMENTS\ATMDB.MDF;Integrated Security=True";
        private int currentBalance;
        string Acc = Login.AccNumber;

        private void InitializeComboBoxes()
        {
            comboBox1.Items.AddRange(new object[] { "Checking", "Savings" });
            comboBox2.Items.AddRange(new object[] { "Checking", "Savings" });

            // Set default values
            comboBox1.SelectedIndex = 0; // Default to "Checking"
            comboBox2.SelectedIndex = 1; // Default to "Savings"

            // Subscribe to SelectedIndexChanged events
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.SelectedIndex = comboBox1.SelectedIndex == 0 ? 1 : 0;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = comboBox2.SelectedIndex == 0 ? 1 : 0;
        }

        private void wdamtTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxAmount.Text) || !int.TryParse(textBoxAmount.Text, out int transferAmount) || transferAmount <= 0)
            {
                MessageBox.Show("Please enter a valid amount to transfer.");
                return;
            }

            string fromAccountType = comboBox1.SelectedItem.ToString();
            string toAccountType = comboBox2.SelectedItem.ToString();

            if (fromAccountType == toAccountType)
            {
                MessageBox.Show("Cannot transfer to the same account type.");
                return;
            }

            // Withdraw from the "from" account
            if (WithdrawAmount(fromAccountType, transferAmount))
            {
                // Deposit to the "to" account
                Deposit deposit = new Deposit { AccountType = toAccountType, Acc = Acc };
                deposit.DepositAmount(transferAmount);

                MessageBox.Show("Transfer completed successfully.");

                this.Hide();
            }
        }

        private bool WithdrawAmount(string accountType, int amount)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "";

                    if (accountType == "Checking")
                    {
                        query = "UPDATE CheckingTbl SET Balance = Balance - @Amount WHERE AccNum = @AccNum AND Balance >= @Amount";
                    }
                    else if (accountType == "Savings")
                    {
                        query = "UPDATE SavingsTbl SET Balance = Balance - @Amount WHERE AccNum = @AccNum AND Balance >= @Amount";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Amount", amount);
                        cmd.Parameters.AddWithValue("@AccNum", Acc);
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            LogTransaction("Withdraw", accountType, amount);
                            return true;
                        }
                        else
                        {
                            MessageBox.Show("Insufficient funds.");
                            return false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error processing withdrawal: " + ex.Message);
                    return false;
                }
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void LogTransaction(string type, string accountType, int amount)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "INSERT INTO TransactionTbl (AccNum, Type, AccountType, Amount, Tdate) VALUES (@AccNum, @Type, @AccountType, @Amount, @Tdate)";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@AccNum", Acc);
                        cmd.Parameters.AddWithValue("@Type", type);
                        cmd.Parameters.AddWithValue("@AccountType", accountType);
                        cmd.Parameters.AddWithValue("@Amount", amount);
                        cmd.Parameters.AddWithValue("@Tdate", DateTime.Now);

                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error logging transaction: " + ex.Message);
                }
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {
            HOME home = new HOME();
            home.Show();
            this.Hide();            
        }
    }
}
