﻿namespace ATM_Management_System
{
    partial class HOME
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label2 = new Label();
            label1 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            panel2 = new Panel();
            label5 = new Label();
            AccNumlbl = new Label();
            button7 = new Button();
            pictureBox2 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateGray;
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(893, 106);
            panel1.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(854, 0);
            label2.Name = "label2";
            label2.Size = new Size(39, 40);
            label2.TabIndex = 3;
            label2.Text = "X";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(233, 32);
            label1.Name = "label1";
            label1.Size = new Size(416, 40);
            label1.TabIndex = 2;
            label1.Text = "Please Select Transaction";
            label1.Click += label1_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.DarkSlateGray;
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Gadugi", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.Control;
            button1.Location = new Point(106, 199);
            button1.Name = "button1";
            button1.Size = new Size(225, 39);
            button1.TabIndex = 9;
            button1.Text = "DEPOSIT";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.DarkSlateGray;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Gadugi", 12F);
            button2.ForeColor = SystemColors.Control;
            button2.Location = new Point(390, 199);
            button2.Name = "button2";
            button2.Size = new Size(225, 39);
            button2.TabIndex = 10;
            button2.Text = "WITHDRAW";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.DarkSlateGray;
            button3.FlatStyle = FlatStyle.Popup;
            button3.Font = new Font("Gadugi", 12F);
            button3.ForeColor = SystemColors.Control;
            button3.Location = new Point(106, 255);
            button3.Name = "button3";
            button3.Size = new Size(225, 39);
            button3.TabIndex = 11;
            button3.Text = "FAST CASH";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.DarkSlateGray;
            button4.FlatStyle = FlatStyle.Popup;
            button4.Font = new Font("Gadugi", 12F);
            button4.ForeColor = SystemColors.Control;
            button4.Location = new Point(390, 255);
            button4.Name = "button4";
            button4.Size = new Size(225, 38);
            button4.TabIndex = 12;
            button4.Text = "MINI STATEMENT";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.DarkSlateGray;
            button5.FlatStyle = FlatStyle.Popup;
            button5.Font = new Font("Gadugi", 12F);
            button5.ForeColor = SystemColors.Control;
            button5.Location = new Point(106, 310);
            button5.Name = "button5";
            button5.Size = new Size(225, 39);
            button5.TabIndex = 13;
            button5.Text = "CHANGE PIN";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.DarkSlateGray;
            button6.FlatStyle = FlatStyle.Popup;
            button6.Font = new Font("Gadugi", 12F);
            button6.ForeColor = SystemColors.Control;
            button6.Location = new Point(390, 310);
            button6.Name = "button6";
            button6.Size = new Size(225, 39);
            button6.TabIndex = 14;
            button6.Text = "BALANCE";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkSlateGray;
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 541);
            panel2.Name = "panel2";
            panel2.Size = new Size(893, 19);
            panel2.TabIndex = 16;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.Control;
            label5.Font = new Font("Gadugi", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.DarkSlateGray;
            label5.Location = new Point(408, 519);
            label5.Name = "label5";
            label5.Size = new Size(62, 19);
            label5.TabIndex = 17;
            label5.Text = "Log Out";
            label5.Click += label5_Click;
            // 
            // AccNumlbl
            // 
            AccNumlbl.AutoSize = true;
            AccNumlbl.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AccNumlbl.ForeColor = SystemColors.WindowFrame;
            AccNumlbl.Location = new Point(304, 109);
            AccNumlbl.Name = "AccNumlbl";
            AccNumlbl.Size = new Size(290, 40);
            AccNumlbl.TabIndex = 4;
            AccNumlbl.Text = "Account Number";
            // 
            // button7
            // 
            button7.BackColor = Color.DarkSlateGray;
            button7.FlatStyle = FlatStyle.Popup;
            button7.Font = new Font("Gadugi", 12F);
            button7.ForeColor = SystemColors.Control;
            button7.Location = new Point(106, 367);
            button7.Name = "button7";
            button7.Size = new Size(225, 39);
            button7.TabIndex = 18;
            button7.Text = "TRANSFER";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Untitled_design__13_;
            pictureBox2.Location = new Point(635, 174);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(230, 211);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 19;
            pictureBox2.TabStop = false;
            // 
            // HOME
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(893, 560);
            Controls.Add(pictureBox2);
            Controls.Add(button7);
            Controls.Add(AccNumlbl);
            Controls.Add(label5);
            Controls.Add(panel2);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "HOME";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "HOME";
            Load += HOME_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Label label2;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Panel panel2;
        private Label label5;
        private Label AccNumlbl;
        private Button button7;
        private PictureBox pictureBox2;
    }
}