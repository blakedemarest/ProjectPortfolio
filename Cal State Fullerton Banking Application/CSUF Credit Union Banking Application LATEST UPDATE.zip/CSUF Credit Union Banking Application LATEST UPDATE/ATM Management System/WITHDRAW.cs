﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Management_System
{
    public partial class WITHDRAW : Form
    {
        public WITHDRAW()
        {
            InitializeComponent();
        }

        public static string AccNumber;
        public string AccountType { get; set; } // Property to hold the selected account type


        private readonly string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=C:\USERS\EARTH\DOCUMENTS\ATMDB.MDF;Integrated Security=True";
        private int currentBalance;
        string Acc = Login.AccNumber;

        private void WITHDRAW_Load(object sender, EventArgs e)
        {
            GetBalance();
        }

        private void addtransaction()
        {
            string TrType = "Withdraw";
            using (SqlConnection con = new SqlConnection(connectionString))
                try
                {
                    con.Open();
                    string query = "INSERT INTO TransactionTbl (AccNum, Type, Amount, Tdate) VALUES (@AccNum, @Type, @Amount, @Tdate)";

                    SqlCommand cmd = new SqlCommand(query, con);

                    cmd.Parameters.AddWithValue("@AccNum", Acc);
                    cmd.Parameters.AddWithValue("@Type", TrType);
                    cmd.Parameters.AddWithValue("@Amount", wdamtTb.Text);
                    cmd.Parameters.AddWithValue("@Tdate", DateTime.Today.Date.ToString("yyyy-MM-dd"));

                    cmd.ExecuteNonQuery();
                    // MessageBox.Show("Account Created Successfully");


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }
                }
        }

        private void GetBalance()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "";

                    if (AccountType == "Checking")
                    {
                        query = "SELECT Balance FROM CheckingTbl WHERE AccNum = @AccNum";
                    }
                    else if (AccountType == "Savings")
                    {
                        query = "SELECT Balance FROM SavingsTbl WHERE AccNum = @AccNum";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@AccNum", Login.AccNumber);
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            currentBalance = Convert.ToInt32(dt.Rows[0]["Balance"]);
                            Balancelbl.Text = "$ " + currentBalance.ToString();
                        }
                        else
                        {
                            MessageBox.Show("Account not found.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving balance: " + ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(wdamtTb.Text))
            {
                MessageBox.Show("Please enter an amount to Withdraw.");
                return;
            }

            if (!int.TryParse(wdamtTb.Text, out int withdrawAmount) || withdrawAmount <= 0)
            {
                MessageBox.Show("Please enter a valid amount.");
                return;
            }

            if (withdrawAmount > currentBalance)
            {
                MessageBox.Show("Insufficient funds. Balance cannot be negative.");
                return;
            }

            WithdrawAmount(withdrawAmount);
        }

        public void WithdrawAmount(int amount)
        {
            int newBalance = currentBalance - amount;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "";

                    if (AccountType == "Checking")
                    {
                        query = "UPDATE CheckingTbl SET Balance = @NewBalance WHERE AccNum = @AccNum";
                    }
                    else if (AccountType == "Savings")
                    {
                        query = "UPDATE SavingsTbl SET Balance = @NewBalance WHERE AccNum = @AccNum";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@NewBalance", newBalance);
                        cmd.Parameters.AddWithValue("@AccNum", Login.AccNumber);
                        cmd.ExecuteNonQuery();

                        MessageBox.Show($"Successfully withdrew ${amount} from your {AccountType} account.");
                        addtransaction();
                        NavigateToHome();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error processing withdrawal: " + ex.Message);
                }
            }
        }

        private void NavigateToHome()
        {
            HOME home = new HOME();
            home.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            NavigateToHome();
        }

        private void wdamtTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}