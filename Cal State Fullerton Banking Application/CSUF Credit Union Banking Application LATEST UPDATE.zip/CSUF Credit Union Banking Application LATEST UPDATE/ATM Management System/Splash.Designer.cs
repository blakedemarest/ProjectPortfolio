﻿namespace ATM_Management_System
{
    partial class Splash
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            myProgress = new ProgressBar();
            Percentage = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Gadugi", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(214, 9);
            label1.Name = "label1";
            label1.Size = new Size(678, 48);
            label1.TabIndex = 0;
            label1.Text = "CSUF ATM MANAGEMENT SYSTEM";
            label1.Click += label1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Untitled_design__13_;
            pictureBox2.Location = new Point(308, 89);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(444, 302);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // myProgress
            // 
            myProgress.Location = new Point(0, 499);
            myProgress.Name = "myProgress";
            myProgress.Size = new Size(1081, 29);
            myProgress.TabIndex = 3;
            myProgress.Click += myProgress_Click;
            // 
            // Percentage
            // 
            Percentage.AutoSize = true;
            Percentage.Font = new Font("Gadugi", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Percentage.ForeColor = Color.White;
            Percentage.Location = new Point(500, 448);
            Percentage.Name = "Percentage";
            Percentage.Size = new Size(55, 48);
            Percentage.TabIndex = 4;
            Percentage.Text = "%";
            Percentage.Click += Percentage_Click;
            // 
            // timer1
            // 
            timer1.Interval = 20;
            timer1.Tick += timer1_Tick;
            // 
            // Splash
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSlateGray;
            ClientSize = new Size(1083, 528);
            Controls.Add(Percentage);
            Controls.Add(myProgress);
            Controls.Add(pictureBox2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Splash";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private ProgressBar myProgress;
        private Label Percentage;
        private System.Windows.Forms.Timer timer1;
    }
}
