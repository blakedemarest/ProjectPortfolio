﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Management_System
{
    public partial class FASTCASH : Form
    {
        private readonly string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=C:\USERS\EARTH\DOCUMENTS\ATMDB.MDF;Integrated Security=True";
        private int currentBalance;
        private readonly SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=C:\USERS\EARTH\DOCUMENTS\ATMDB.MDF;Integrated Security=True");
        private readonly string Acc = Login.AccNumber;

        public FASTCASH()
        {
            InitializeComponent();
        }

        // Method to fetch and display the current balance
        private void getbalance()
        {
            try
            {
                con.Open();
                string query = "SELECT Balance FROM AccountTbl WHERE AccNum=@AccNum";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@AccNum", Acc);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    Balancelbl.Text = "Balance: $ " + dt.Rows[0][0].ToString();
                    currentBalance = Convert.ToInt32(dt.Rows[0][0]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching balance: {ex.Message}");
            }
            finally
            {
                con.Close();
            }
        }

        // Event handler for label5 click to navigate to the HOME form
        private void label5_Click(object sender, EventArgs e)
        {
            HOME home = new HOME();
            home.Show();
            this.Hide();
        }

        // Event handler for FASTCASH form load
        private void FASTCASH_Load(object sender, EventArgs e)
        {
            getbalance();
        }

        // Method to add a transaction record
        private void addtransaction(int amt)
        {
            string TrType = "Withdraw";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "INSERT INTO TransactionTbl (AccNum, Type, Amount, Tdate) VALUES (@AccNum, @Type, @Amount, @Tdate)";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@AccNum", Acc);
                        cmd.Parameters.AddWithValue("@Type", TrType);
                        cmd.Parameters.AddWithValue("@Amount", amt);
                        cmd.Parameters.AddWithValue("@Tdate", DateTime.Today.Date.ToString("yyyy-MM-dd"));
                        cmd.ExecuteNonQuery();
                    }

                    Login log = new Login();
                    log.Show();
                    this.Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error adding transaction: {ex.Message}");
                }
            }
        }

        // Method to withdraw a specified amount
        public void WithdrawAmount(int amount)
        {
            if (currentBalance < amount)
            {
                MessageBox.Show("Insufficient funds. Your balance cannot be negative.");
                return;
            }

            int newBalance = currentBalance - amount;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "UPDATE AccountTbl SET Balance = @NewBalance WHERE AccNum = @AccNum";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@NewBalance", newBalance);
                        cmd.Parameters.AddWithValue("@AccNum", Login.AccNumber);
                        cmd.ExecuteNonQuery();

                        MessageBox.Show($"Successfully withdrew ${amount} from your account.");
                        addtransaction(amount);
                        NavigateToHome();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error processing withdrawal: {ex.Message}");
                }
            }
        }

        // Method to navigate to the HOME form
        private void NavigateToHome()
        {
            HOME home = new HOME();
            home.Show();
            this.Hide();
        }

        // Event handlers for withdrawal buttons
        private void button1_Click(object sender, EventArgs e) => WithdrawAmount(20);
        private void button2_Click(object sender, EventArgs e) => WithdrawAmount(40);
        private void button3_Click(object sender, EventArgs e) => WithdrawAmount(60);
        private void button4_Click(object sender, EventArgs e) => WithdrawAmount(80);
        private void button5_Click(object sender, EventArgs e) => WithdrawAmount(100);
        private void button6_Click(object sender, EventArgs e) => WithdrawAmount(200);

        // Event handler for label6 click to navigate to the Login form
        private void label6_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }
    }
}
