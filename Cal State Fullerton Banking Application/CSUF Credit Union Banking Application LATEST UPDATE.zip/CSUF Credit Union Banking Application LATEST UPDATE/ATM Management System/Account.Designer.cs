﻿namespace ATM_Management_System
{
    partial class Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label2 = new Label();
            label1 = new Label();
            label5 = new Label();
            label3 = new Label();
            label4 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label12 = new Label();
            AccNumTb = new TextBox();
            AccNameTb = new TextBox();
            FanameTb = new TextBox();
            AddressTb = new TextBox();
            PhoneTb = new TextBox();
            PinTb = new TextBox();
            EducationTb = new ComboBox();
            dobdate = new DateTimePicker();
            panel2 = new Panel();
            label13 = new Label();
            button1 = new Button();
            OccupationTb = new TextBox();
            pictureBox2 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateGray;
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1327, 106);
            panel1.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(1288, 0);
            label2.Name = "label2";
            label2.Size = new Size(39, 40);
            label2.TabIndex = 3;
            label2.Text = "X";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Gadugi", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(379, 43);
            label1.Name = "label1";
            label1.Size = new Size(582, 40);
            label1.TabIndex = 2;
            label1.Text = "CSUF ATM MANAGEMENT SYSTEM";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.Control;
            label5.Font = new Font("Gadugi", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.DarkSlateGray;
            label5.Location = new Point(132, 163);
            label5.Name = "label5";
            label5.Size = new Size(119, 27);
            label5.TabIndex = 10;
            label5.Text = "ACC NUM";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.Control;
            label3.Font = new Font("Gadugi", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.DarkSlateGray;
            label3.Location = new Point(132, 209);
            label3.Name = "label3";
            label3.Size = new Size(146, 27);
            label3.TabIndex = 11;
            label3.Text = "FIRST NAME";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.Control;
            label4.Font = new Font("Gadugi", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.DarkSlateGray;
            label4.Location = new Point(132, 303);
            label4.Name = "label4";
            label4.Size = new Size(115, 27);
            label4.TabIndex = 12;
            label4.Text = "ADDRESS";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = SystemColors.Control;
            label6.Font = new Font("Gadugi", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.DarkSlateGray;
            label6.Location = new Point(132, 256);
            label6.Name = "label6";
            label6.Size = new Size(140, 27);
            label6.TabIndex = 13;
            label6.Text = "LAST NAME";
            label6.Click += label6_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = SystemColors.Control;
            label7.Font = new Font("Gadugi", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.DarkSlateGray;
            label7.Location = new Point(740, 204);
            label7.Name = "label7";
            label7.Size = new Size(143, 27);
            label7.TabIndex = 14;
            label7.Text = "EDUCATION";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = SystemColors.Control;
            label8.Font = new Font("Gadugi", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.DarkSlateGray;
            label8.Location = new Point(740, 251);
            label8.Name = "label8";
            label8.Size = new Size(159, 27);
            label8.TabIndex = 15;
            label8.Text = "OCCUPATION";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = SystemColors.Control;
            label9.Font = new Font("Gadugi", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.DarkSlateGray;
            label9.Location = new Point(740, 293);
            label9.Name = "label9";
            label9.Size = new Size(61, 27);
            label9.TabIndex = 16;
            label9.Text = "DOB";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = SystemColors.Control;
            label10.Font = new Font("Gadugi", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.DarkSlateGray;
            label10.Location = new Point(740, 163);
            label10.Name = "label10";
            label10.Size = new Size(51, 27);
            label10.TabIndex = 17;
            label10.Text = "PIN";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = SystemColors.Control;
            label12.Font = new Font("Gadugi", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.DarkSlateGray;
            label12.Location = new Point(132, 345);
            label12.Name = "label12";
            label12.Size = new Size(91, 27);
            label12.TabIndex = 19;
            label12.Text = "PHONE";
            // 
            // AccNumTb
            // 
            AccNumTb.Font = new Font("Gadugi", 10F);
            AccNumTb.Location = new Point(287, 163);
            AccNumTb.Name = "AccNumTb";
            AccNumTb.Size = new Size(194, 30);
            AccNumTb.TabIndex = 20;
            // 
            // AccNameTb
            // 
            AccNameTb.Font = new Font("Gadugi", 10F);
            AccNameTb.Location = new Point(287, 206);
            AccNameTb.Name = "AccNameTb";
            AccNameTb.Size = new Size(194, 30);
            AccNameTb.TabIndex = 21;
            // 
            // FanameTb
            // 
            FanameTb.Font = new Font("Gadugi", 10F);
            FanameTb.Location = new Point(287, 253);
            FanameTb.Name = "FanameTb";
            FanameTb.Size = new Size(194, 30);
            FanameTb.TabIndex = 22;
            // 
            // AddressTb
            // 
            AddressTb.Font = new Font("Gadugi", 10F);
            AddressTb.Location = new Point(287, 300);
            AddressTb.Name = "AddressTb";
            AddressTb.Size = new Size(194, 30);
            AddressTb.TabIndex = 23;
            // 
            // PhoneTb
            // 
            PhoneTb.Font = new Font("Gadugi", 10F);
            PhoneTb.Location = new Point(287, 342);
            PhoneTb.Name = "PhoneTb";
            PhoneTb.Size = new Size(194, 30);
            PhoneTb.TabIndex = 24;
            // 
            // PinTb
            // 
            PinTb.Font = new Font("Gadugi", 10F);
            PinTb.Location = new Point(927, 160);
            PinTb.Name = "PinTb";
            PinTb.Size = new Size(194, 30);
            PinTb.TabIndex = 25;
            // 
            // EducationTb
            // 
            EducationTb.Font = new Font("Gadugi", 10F);
            EducationTb.FormattingEnabled = true;
            EducationTb.Items.AddRange(new object[] { "High School", "Undergraduate", "Graduate" });
            EducationTb.Location = new Point(927, 203);
            EducationTb.Name = "EducationTb";
            EducationTb.Size = new Size(194, 28);
            EducationTb.TabIndex = 30;
            // 
            // dobdate
            // 
            dobdate.Font = new Font("Gadugi", 8F);
            dobdate.Location = new Point(927, 293);
            dobdate.Name = "dobdate";
            dobdate.Size = new Size(194, 25);
            dobdate.TabIndex = 32;
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkSlateGray;
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 658);
            panel2.Name = "panel2";
            panel2.Size = new Size(1327, 16);
            panel2.TabIndex = 33;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = SystemColors.Control;
            label13.Font = new Font("Gadugi", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.DarkSlateGray;
            label13.Location = new Point(624, 636);
            label13.Name = "label13";
            label13.Size = new Size(62, 19);
            label13.TabIndex = 18;
            label13.Text = "Log Out";
            label13.Click += label13_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.DarkSlateGray;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Gadugi", 9F, FontStyle.Bold);
            button1.ForeColor = SystemColors.Control;
            button1.Location = new Point(592, 479);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 34;
            button1.Text = "SUBMIT";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // OccupationTb
            // 
            OccupationTb.Font = new Font("Gadugi", 10F);
            OccupationTb.Location = new Point(927, 248);
            OccupationTb.Name = "OccupationTb";
            OccupationTb.Size = new Size(194, 30);
            OccupationTb.TabIndex = 35;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Untitled_design__13_;
            pictureBox2.Location = new Point(865, 324);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(319, 259);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 36;
            pictureBox2.TabStop = false;
            // 
            // Account
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1327, 674);
            Controls.Add(pictureBox2);
            Controls.Add(OccupationTb);
            Controls.Add(button1);
            Controls.Add(label13);
            Controls.Add(panel2);
            Controls.Add(dobdate);
            Controls.Add(EducationTb);
            Controls.Add(PinTb);
            Controls.Add(PhoneTb);
            Controls.Add(AddressTb);
            Controls.Add(FanameTb);
            Controls.Add(AccNameTb);
            Controls.Add(AccNumTb);
            Controls.Add(label12);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label5);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Account";
            Text = "Account";
            Load += Account_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label2;
        private Label label1;
        private Label label5;
        private Label label3;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label12;
        private TextBox AccNumTb;
        private TextBox AccNameTb;
        private TextBox FanameTb;
        private TextBox AddressTb;
        private TextBox PhoneTb;
        private TextBox PinTb;
        private ComboBox EducationTb;
        private DateTimePicker dobdate;
        private Panel panel2;
        private Label label13;
        private Button button1;
        private TextBox OccupationTb;
        private PictureBox pictureBox2;
    }
}