﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Management_System
{
    public partial class SelectAccount : Form
    {
        public SelectAccount()
        {
            InitializeComponent();
        }

        private void CheckingBtn_Click(object sender, EventArgs e)
        {
            NavigateToTransaction("Checking");
        }

        private void SavingsBtn_Click(object sender, EventArgs e)
        {
            NavigateToTransaction("Savings");
        }

        private void NavigateToTransaction(string accountType)
        {
            if (HOME.TransactionType == "Deposit")
            {
                Deposit deposit = new Deposit();
                deposit.AccountType = accountType;
                deposit.Show();
            }
            else if (HOME.TransactionType == "Withdraw")
            {
                WITHDRAW withdraw = new WITHDRAW();
                withdraw.AccountType = accountType;
                withdraw.Show();
            }
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            HOME home = new HOME();
            home.Show();
            this.Hide();
        }
    }
}
