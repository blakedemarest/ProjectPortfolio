﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ATM_Management_System
{
    public partial class Account : Form
    {
        public Account()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=C:\USERS\EARTH\DOCUMENTS\ATMDB.MDF;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            if (AccNumTb.Text == "" || AccNameTb.Text == "" || FanameTb.Text == "" || PhoneTb.Text == "" || AddressTb.Text == "" || EducationTb.SelectedIndex == -1 || OccupationTb.Text == "" || PinTb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();

                    // Insert into AccountTbl
                    string accountQuery = "INSERT INTO AccountTbl (AccNum, Name, FaName, Dob, Phone, Address, Education, Occupation, PIN) VALUES (@AccNum, @Name, @FaName, @Dob, @Phone, @Address, @Education, @Occupation, @PIN)";
                    SqlCommand accountCmd = new SqlCommand(accountQuery, con);
                    accountCmd.Parameters.AddWithValue("@AccNum", AccNumTb.Text);
                    accountCmd.Parameters.AddWithValue("@Name", AccNameTb.Text);
                    accountCmd.Parameters.AddWithValue("@FaName", FanameTb.Text);
                    accountCmd.Parameters.AddWithValue("@Dob", dobdate.Value.Date.ToString("yyyy-MM-dd"));
                    accountCmd.Parameters.AddWithValue("@Phone", PhoneTb.Text);
                    accountCmd.Parameters.AddWithValue("@Address", AddressTb.Text);
                    accountCmd.Parameters.AddWithValue("@Education", EducationTb.SelectedItem.ToString());
                    accountCmd.Parameters.AddWithValue("@Occupation", OccupationTb.Text);
                    accountCmd.Parameters.AddWithValue("@PIN", PinTb.Text);
                    accountCmd.ExecuteNonQuery();

                    // Insert initial balance into CheckingTbl
                    string checkingQuery = "INSERT INTO CheckingTbl (AccNum, Balance) VALUES (@AccNum, @Balance)";
                    SqlCommand checkingCmd = new SqlCommand(checkingQuery, con);
                    checkingCmd.Parameters.AddWithValue("@AccNum", AccNumTb.Text);
                    checkingCmd.Parameters.AddWithValue("@Balance", 0); // Initial balance is set to 0
                    checkingCmd.ExecuteNonQuery();

                    // Insert initial balance into SavingsTbl
                    string savingsQuery = "INSERT INTO SavingsTbl (AccNum, Balance) VALUES (@AccNum, @Balance)";
                    SqlCommand savingsCmd = new SqlCommand(savingsQuery, con);
                    savingsCmd.Parameters.AddWithValue("@AccNum", AccNumTb.Text);
                    savingsCmd.Parameters.AddWithValue("@Balance", 0); // Initial balance is set to 0
                    savingsCmd.ExecuteNonQuery();

                    MessageBox.Show("Account Created Successfully");

                    Login log = new Login();
                    log.Show();
                    this.Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }
                }
            }
        }

        private void Account_Load(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            log.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
 

