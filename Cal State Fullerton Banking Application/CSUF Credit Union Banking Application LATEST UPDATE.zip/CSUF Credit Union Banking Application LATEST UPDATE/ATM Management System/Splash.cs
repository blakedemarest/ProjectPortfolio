namespace ATM_Management_System
{
    public partial class Splash : Form
    {
        public Splash()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        int starting = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            starting += 1;
            myProgress.Value = starting;
            Percentage.Text = starting + "%";
            if (myProgress.Value == 100)
            {
                myProgress.Value = 0;
                timer1.Stop();
                Login log = new Login();
                this.Hide();
                log.Show();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Calculate the center position
            int x = (this.ClientSize.Width - pictureBox1.Width) / 2;
            int y = (this.ClientSize.Height - pictureBox1.Height) / 2;

            // Set the PictureBox location
            pictureBox1.Location = new Point(x, y);
        }

        private void Percentage_Click(object sender, EventArgs e)
        {

        }

        private void myProgress_Click(object sender, EventArgs e)
        {

        }
    }
}
