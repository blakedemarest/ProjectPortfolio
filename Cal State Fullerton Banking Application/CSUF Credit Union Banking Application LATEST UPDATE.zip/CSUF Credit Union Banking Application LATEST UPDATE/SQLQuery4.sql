﻿ALTER TABLE TransactionTbl
ADD AccountType VARCHAR(50);
